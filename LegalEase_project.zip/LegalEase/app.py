import os
from datetime import date

import requests
import streamlit as st
from dotenv import load_dotenv

from services.document_export import format_docx, format_pdf, format_txt
from services.text_utils import text_to_html

load_dotenv()

st.set_page_config(
    page_title="LegalEase",
    page_icon="⚖️",
    layout="wide",
)

BACKEND_URL = os.getenv("BACKEND_URL", "http://127.0.0.1:8000").rstrip("/")

st.markdown(
    """
    <style>
    .hero { padding: 1rem 0 0.5rem 0; }
    .hero h1 { margin-bottom: 0.1rem; }
    .muted { color: #7c8798; }
    .preview {
        background: #111827;
        color: #f3f4f6;
        border-radius: 12px;
        padding: 24px;
        max-height: 620px;
        overflow-y: auto;
        line-height: 1.65;
        border: 1px solid #374151;
    }
    .preview h3 { color: #fff; margin-top: 1rem; }
    .preview p { color: #e5e7eb; }
    .notice {
        background: #fff7ed;
        border: 1px solid #fed7aa;
        padding: 12px 16px;
        border-radius: 8px;
        color: #7c2d12;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="hero"><h1>⚖️ LegalEase</h1>'
    '<div class="muted">AI-powered legal document drafting workspace</div></div>',
    unsafe_allow_html=True,
)

st.markdown(
    '<div class="notice"><strong>Review notice:</strong> LegalEase creates drafts, '
    "not legal advice. Review jurisdiction-specific requirements with a qualified "
    "professional before signing.</div>",
    unsafe_allow_html=True,
)
st.write("")

with st.sidebar:
    st.subheader("Document settings")
    document_type = st.text_input(
        "Document type",
        value="Freelance Work Contract",
        help="Examples: NDA, Lease Agreement, Employment Contract.",
    )
    parties = st.text_area(
        "Parties involved",
        value="Jane Doe (Service Provider), TechNova Inc. (Client)",
        height=110,
    )
    terms = st.text_area(
        "Terms & conditions",
        value=(
            "Payment to be made within 30 days of invoice; "
            "The provider agrees to deliver work by the agreed deadline; "
            "Confidentiality must be maintained; "
            "Either party may terminate with 15 days notice"
        ),
        height=180,
        help="Separate clauses with semicolons.",
    )
    dates = st.text_input("Effective date", value=date.today().strftime("%B %d, %Y"))

    generate = st.button("Generate Document", type="primary", use_container_width=True)

if "document" not in st.session_state:
    st.session_state.document = ""
if "document_type" not in st.session_state:
    st.session_state.document_type = document_type

if generate:
    payload = {
        "document_type": document_type,
        "parties": parties,
        "terms": terms,
        "dates": dates,
    }
    try:
        with st.spinner("Generating your draft..."):
            response = requests.post(
                f"{BACKEND_URL}/generate",
                json=payload,
                timeout=120,
            )
        if response.ok:
            data = response.json()
            st.session_state.document = data["content"]
            st.session_state.document_type = data["document_type"]
            st.success("Document generated.")
        else:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            st.error(f"Backend error: {detail}")
    except requests.RequestException as exc:
        st.error(
            "Could not reach the FastAPI backend. Start it with "
            "`uvicorn backend.main:app --reload`."
        )
        st.caption(str(exc))

left, right = st.columns(2)

with left:
    st.subheader("Preview")
    if st.session_state.document:
        st.markdown(
            f'<div class="preview">{text_to_html(st.session_state.document)}</div>',
            unsafe_allow_html=True,
        )
    else:
        st.info("Your generated document will appear here.")

with right:
    st.subheader("Edit document")
    edited = st.text_area(
        "Editable document text",
        value=st.session_state.document,
        height=520,
        label_visibility="collapsed",
    )
    if st.session_state.document:
        st.session_state.document = edited

st.divider()
st.subheader("Export")

if st.session_state.document:
    c1, c2, c3 = st.columns(3)
    safe_name = "".join(
        ch.lower() if ch.isalnum() else "-"
        for ch in st.session_state.document_type
    ).strip("-") or "legalease-document"

    with c1:
        st.download_button(
            "Download TXT",
            data=format_txt(st.session_state.document),
            file_name=f"{safe_name}.txt",
            mime="text/plain",
            use_container_width=True,
        )
    with c2:
        st.download_button(
            "Download DOCX",
            data=format_docx(st.session_state.document, st.session_state.document_type),
            file_name=f"{safe_name}.docx",
            mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            use_container_width=True,
        )
    with c3:
        st.download_button(
            "Download PDF",
            data=format_pdf(st.session_state.document, st.session_state.document_type),
            file_name=f"{safe_name}.pdf",
            mime="application/pdf",
            use_container_width=True,
        )
else:
    st.caption("Generate a document first to enable downloads.")
