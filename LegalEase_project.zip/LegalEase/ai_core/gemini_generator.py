import os

from dotenv import load_dotenv

from .prompts import SYSTEM_INSTRUCTION, build_prompt

load_dotenv()


class GeminiDocumentGenerator:
    def __init__(self, client=None, model: str | None = None):
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
        self.api_key = os.getenv("GEMINI_API_KEY")

        if client is not None:
            self.client = client
            return

        if not self.api_key:
            raise ValueError(
                "GEMINI_API_KEY is not configured. Add it to your .env file."
            )

        # Lazy import keeps unit tests and non-AI routes usable without
        # importing the external SDK until an actual Gemini request is made.
        from google import genai

        self.client = genai.Client(api_key=self.api_key)

    def generate_document(
        self,
        document_type: str,
        parties: str,
        terms: str,
        dates: str,
    ) -> str:
        from google.genai import types

        prompt = build_prompt(document_type, parties, terms, dates)

        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_INSTRUCTION,
                temperature=0.35,
                max_output_tokens=5000,
            ),
        )

        text = getattr(response, "text", None)
        if not text or not text.strip():
            raise RuntimeError("Gemini returned an empty response.")

        return text.strip()
