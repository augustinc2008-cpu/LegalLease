# LegalEase — AI-Powered Legal Document Generator

LegalEase is a full-stack reference implementation based on the supplied project specification:
- Streamlit frontend
- FastAPI backend
- Google Gemini generation
- Editable preview
- TXT, DOCX, and PDF export
- Optional branding/logo
- Terms table/structured formatting in DOCX
- Automated API/unit tests
- Docker configuration

> LegalEase generates draft legal text and is not a substitute for advice from a qualified lawyer. Review generated documents for your jurisdiction and circumstances before signing or relying on them.

## Architecture

```text
Streamlit UI
   |
   | HTTP POST /generate
   v
FastAPI API
   |
   v
GeminiDocumentGenerator -> Google Gemini API
   |
   v
Generated legal document text
   |
   +--> HTML preview
   +--> TXT
   +--> DOCX
   +--> PDF
```

## Project structure

```text
LegalEase/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── Dockerfile
├── docker-compose.yml
├── Procfile
├── LICENSE
├── README.md
├── backend/
│   ├── __init__.py
│   ├── main.py
│   ├── routes.py
│   └── schemas.py
├── ai_core/
│   ├── __init__.py
│   ├── gemini_generator.py
│   └── prompts.py
├── services/
│   ├── __init__.py
│   ├── document_export.py
│   └── text_utils.py
├── assets/
│   └── logo.svg
└── tests/
    ├── __init__.py
    ├── test_api.py
    └── test_exports.py
```

## 1. Requirements

Python 3.10+ is recommended.

You need a Google Gemini API key for live AI generation.

The original specification calls for `google-generativeai` and Gemini 1.5 Pro. Google now recommends the newer `google-genai` SDK, so this implementation uses that maintained SDK. The model is configurable through `GEMINI_MODEL`; the default is `gemini-3.8-flash`.

## 2. VS Code setup

Open the `LegalEase` folder in VS Code.

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` and set:

```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-3.8-flash
BACKEND_URL=http://127.0.0.1:8000
CORS_ORIGINS=http://localhost:8501,http://127.0.0.1:8501
```

If your Google account/project exposes another current Gemini model, set that model ID instead.

## 3. Run the backend

Terminal 1:

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Check:
- http://127.0.0.1:8000/
- http://127.0.0.1:8000/health
- http://127.0.0.1:8000/docs

## 4. Run the frontend

Terminal 2:

```powershell
.\.venv\Scripts\Activate.ps1
streamlit run app.py
```

Open the URL Streamlit prints, normally `http://localhost:8501`.

## 5. Generate a document

Example:
- Document type: `Freelance Work Contract`
- Parties: `Jane Doe (Service Provider), TechNova Inc. (Client)`
- Terms: `Payment within 30 days of invoice; Provider delivers agreed milestones; Confidentiality applies; Either party may terminate with 15 days notice`
- Effective date: `April 15, 2025`

Click **Generate Document**. The generated text can be edited and exported as TXT, DOCX, or PDF.

## 6. Run tests

The tests do not call Gemini. The API test injects a fake generator, so the suite can run without an API key.

```powershell
pytest -q
```

## 7. Docker

```bash
docker compose up --build
```

Backend: `http://localhost:8000`  
Frontend: `http://localhost:8501`

Put your Gemini key in `.env` before starting Docker.

## API

### POST `/generate`

Request:

```json
{
  "document_type": "Non-Disclosure Agreement",
  "parties": "Alice Smith (Disclosing Party), Example Labs (Receiving Party)",
  "terms": "Confidential information must be protected; Disclosure is permitted only for the stated purpose",
  "dates": "September 28, 2026"
}
```

Response:

```json
{
  "document_type": "Non-Disclosure Agreement",
  "content": "..."
}
```

### GET `/health`

Returns:

```json
{"status":"ok"}
```

## Production notes

Before public deployment:
- Put the API behind HTTPS.
- Store secrets in the deployment platform's secret manager.
- Add authentication and rate limiting.
- Configure restrictive CORS.
- Avoid unnecessary retention of sensitive legal text.
- Review privacy/data-retention requirements for your jurisdiction.
- Have a legal professional review production prompts/templates.
