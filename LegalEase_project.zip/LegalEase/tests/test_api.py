from fastapi.testclient import TestClient

from backend.main import app
from backend.routes import get_generator


class FakeGenerator:
    def generate_document(self, document_type, parties, terms, dates):
        return (
            f"{document_type.upper()}\n\n"
            f"Parties: {parties}\n\n"
            f"Effective Date: {dates}\n\n"
            f"Terms: {terms}"
        )


app.dependency_overrides[get_generator] = lambda: FakeGenerator()
client = TestClient(app)


def teardown_module():
    app.dependency_overrides.clear()


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_generate():
    response = client.post(
        "/generate",
        json={
            "document_type": "NDA",
            "parties": "A and B",
            "terms": "Keep information confidential",
            "dates": "2026-09-28",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["document_type"] == "NDA"
    assert "KEEP INFORMATION CONFIDENTIAL" in data["content"].upper()


def test_validation_rejects_blank_terms():
    response = client.post(
        "/generate",
        json={
            "document_type": "NDA",
            "parties": "A and B",
            "terms": "",
            "dates": "2026-09-28",
        },
    )
    assert response.status_code == 422
