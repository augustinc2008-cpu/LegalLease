from services.document_export import format_docx, format_pdf, format_txt
from services.text_utils import sanitize_text, text_to_html

TEXT = """FREELANCE WORK CONTRACT

1. PARTIES
Jane Doe and Example Corp.

- Payment within 30 days.
- Confidentiality applies.
"""


def test_sanitize_text():
    result = sanitize_text("Hello\u2014world  ")
    assert result == "Hello-world"


def test_html_preview_escapes_markup():
    html = text_to_html("<script>alert(1)</script>")
    assert "<script>" not in html
    assert "&lt;script&gt;" in html


def test_txt_export():
    data = format_txt(TEXT)
    assert b"FREELANCE WORK CONTRACT" in data


def test_docx_export():
    data = format_docx(TEXT, "Freelance Work Contract")
    assert data[:2] == b"PK"


def test_pdf_export():
    data = format_pdf(TEXT, "Freelance Work Contract")
    assert data.startswith(b"%PDF")
