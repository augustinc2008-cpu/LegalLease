import os

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routes import router

load_dotenv()

APP_NAME = os.getenv("APP_NAME", "LegalEase")
origins = [
    item.strip()
    for item in os.getenv(
        "CORS_ORIGINS",
        "http://localhost:8501,http://127.0.0.1:8501",
    ).split(",")
    if item.strip()
]

app = FastAPI(
    title=APP_NAME,
    description="AI-powered legal document drafting API.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

app.include_router(router)


@app.get("/")
def root():
    return {
        "name": APP_NAME,
        "message": "LegalEase API is running.",
        "docs": "/docs",
    }


@app.get("/health")
def health():
    return {"status": "ok"}
