from fastapi import APIRouter, Depends, HTTPException

from ai_core.gemini_generator import GeminiDocumentGenerator
from .schemas import DocumentRequest, DocumentResponse

router = APIRouter()


def get_generator() -> GeminiDocumentGenerator:
    return GeminiDocumentGenerator()


@router.post("/generate", response_model=DocumentResponse)
def generate_document(
    request: DocumentRequest,
    generator: GeminiDocumentGenerator = Depends(get_generator),
):
    try:
        content = generator.generate_document(
            document_type=request.document_type,
            parties=request.parties,
            terms=request.terms,
            dates=request.dates,
        )
        return DocumentResponse(
            document_type=request.document_type,
            content=content,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Document generation failed: {exc}",
        ) from exc
