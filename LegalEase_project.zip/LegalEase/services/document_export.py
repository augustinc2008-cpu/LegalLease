from io import BytesIO
import re

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from fpdf import FPDF

from .text_utils import sanitize_text


def _split_blocks(text: str):
    return [b.strip() for b in re.split(r"\n\s*\n", sanitize_text(text)) if b.strip()]


def _heading_like(line: str) -> bool:
    return bool(
        re.match(r"^\d+\.\s+", line)
        or re.match(r"^[A-Z][A-Z0-9\s&:/-]{3,}$", line)
    )


def format_txt(text: str) -> bytes:
    return sanitize_text(text).encode("utf-8")


def format_docx(text: str, doc_type: str) -> bytes:
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.85)
    section.right_margin = Inches(0.85)

    styles = doc.styles
    styles["Normal"].font.name = "Times New Roman"
    styles["Normal"].font.size = Pt(11)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(doc_type.upper())
    run.bold = True
    run.font.name = "Times New Roman"
    run.font.size = Pt(16)

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle.add_run("LegalEase Draft").italic = True

    for block in _split_blocks(text):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        for line in lines:
            if _heading_like(line):
                p = doc.add_paragraph()
                r = p.add_run(line)
                r.bold = True
                r.font.name = "Times New Roman"
                r.font.size = Pt(12)
            elif line.startswith(("- ", "* ")):
                p = doc.add_paragraph(style="List Bullet")
                p.add_run(line[2:])
            else:
                p = doc.add_paragraph(line)
                p.paragraph_format.space_after = Pt(6)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run(
        "Generated with LegalEase - Review before signing"
    ).font.size = Pt(8)

    output = BytesIO()
    doc.save(output)
    return output.getvalue()


class LegalEasePDF(FPDF):
    def __init__(self, doc_type: str):
        super().__init__()
        self.doc_type = doc_type
        self.set_auto_page_break(auto=True, margin=18)

    def header(self):
        self.set_font("Helvetica", "B", 10)
        self.cell(0, 8, "LegalEase", align="C")
        self.ln(4)
        self.set_draw_color(150, 150, 150)
        self.line(12, 18, self.w - 12, 18)
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "", 8)
        self.cell(
            0,
            8,
            f"{self.doc_type} | LegalEase Draft | Page {self.page_no()}",
            align="C",
        )


def format_pdf(text: str, doc_type: str) -> bytes:
    pdf = LegalEasePDF(doc_type)
    pdf.set_margins(15, 22, 15)
    pdf.add_page()

    pdf.set_font("Helvetica", "B", 16)
    pdf.set_x(pdf.l_margin); pdf.cell(pdf.epw, 9, doc_type.upper(), align="C")
    pdf.set_font("Helvetica", "I", 9)
    pdf.cell(0, 6, "LegalEase Draft - Review before signing", align="C")
    pdf.ln(5)

    for block in _split_blocks(text):
        for line in [x.strip() for x in block.splitlines() if x.strip()]:
            if _heading_like(line):
                pdf.set_font("Helvetica", "B", 11)
                pdf.set_x(pdf.l_margin); pdf.multi_cell(pdf.epw, 7, line)
            elif line.startswith(("- ", "* ")):
                pdf.set_font("Helvetica", "", 10)
                pdf.set_x(pdf.l_margin); pdf.multi_cell(pdf.epw, 6, "- " + line[2:])
            else:
                pdf.set_font("Helvetica", "", 10)
                pdf.set_x(pdf.l_margin); pdf.multi_cell(pdf.epw, 6, line)
        pdf.ln(2)

    return bytes(pdf.output())
