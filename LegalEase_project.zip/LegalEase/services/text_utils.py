import html
import re


def sanitize_text(text: str) -> str:
    text = text.replace("\u2018", "'").replace("\u2019", "'")
    text = text.replace("\u201c", '"').replace("\u201d", '"')
    text = text.replace("\u2013", "-").replace("\u2014", "-")
    text = text.replace("\u00a0", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def text_to_html(text: str) -> str:
    safe = html.escape(sanitize_text(text))
    paragraphs = []

    for block in safe.split("\n\n"):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if not lines:
            continue

        rendered = []
        for line in lines:
            if re.match(r"^\d+\.\s+", line) or re.match(r"^[A-Z][A-Z0-9\s&-]{3,}$", line):
                rendered.append(f"<h3>{line}</h3>")
            elif line.startswith(("- ", "* ")):
                rendered.append(f"<li>{line[2:]}</li>")
            else:
                rendered.append(f"<p>{line}</p>")

        joined = "\n".join(rendered)
        if "<li>" in joined:
            joined = f"<ul>{joined}</ul>"
        paragraphs.append(joined)

    return "\n".join(paragraphs)
